---
id: spec-reference
type: reference
title: The Spec (Artifact B) — reference
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon]
links: [house-canon-index, methodology-reference]
edit_policy: locked
review_required: false
gated: false
authority: canonical
---
# The Spec (Artifact B)

The normative specification the consultative agent enforces when building any wiki. Defines foundational conventions, the primitive catalogue, the invariants, the governance model, the prescription package, the build method, strategic/tactical handling, and industry onboarding.

The agent treats the Spec as the authority for *how* to build. When a client wiki must deviate, the deviation is recorded with reason per the Spec's normative-language rules (MUST / SHOULD / MAY).
