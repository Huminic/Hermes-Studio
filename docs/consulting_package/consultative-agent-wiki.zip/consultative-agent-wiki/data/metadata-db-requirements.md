---
id: metadata-db-requirements
type: data-contract
title: Metadata DB Requirements
status: active
domain: data
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [data, metadata]
links: [wiki-semantic-agent-template, database-semantic-agent-template]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Metadata DB Requirements

The always-on substrate. At minimum, every wiki interaction is recorded. This defines *what must be recorded*, not the physical schema.

## Output description
A record per wiki interaction.

## Destination
The per-client metadata database, governed by the database semantic agent.

## Shape (what must be captured)
- actor (role + human/agent token identity)
- action (read / create / update / deprecate / archive)
- target page id + version before/after
- timestamp
- reason (for governed edits)
- gate event reference (if the action was gated)

## Write guarantees
Append-only for the audit trail; updates to derived views are separate.

## Logging expectations
Sufficient to answer "what changed in this wiki since X, and on whose authority" and to drive drift observability.
