---
id: hot
type: reference
title: Hot Cache
status: active
domain: meta
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [cache]
links: []
edit_policy: open
review_required: false
gated: false
authority: canonical
---
# Hot Cache
Rolling cache of most-recent context (~500 chars). Updated by the semantic agent.

Current: Wiki initialized 2026-05-27. No active client engagement. Method, onboarding protocol, and client-delivery strawman are live. Awaiting first intake.
