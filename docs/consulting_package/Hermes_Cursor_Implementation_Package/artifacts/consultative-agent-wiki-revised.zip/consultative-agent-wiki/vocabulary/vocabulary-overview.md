---
id: vocabulary-overview
type: reference
title: Vocabulary — Overview
status: active
domain: vocabulary
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [vocabulary]
links: [index]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Vocabulary — Overview

Client-term ↔ canonical-term mappings. For the consultative agent's own wiki, the canonical vocabulary is the Spec's. Client wikis accumulate entries during audit as the agent encounters client-specific terms.

## Example canonical terms
- **primitive** — a page archetype (Spec §3).
- **strawman** — an opinionated default led with during intake.
- **ghost container** — an empty folder describing what could live there.
- **relay** — a point where the agent pauses for a human.
