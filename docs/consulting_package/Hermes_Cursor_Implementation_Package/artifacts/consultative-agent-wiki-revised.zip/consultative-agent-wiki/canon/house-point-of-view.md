---
id: house-point-of-view
type: framework
title: House Point of View — The Strawman Stance
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon, posture, strawman]
links: [house-canon-index, strawman-library-overview, audit]
edit_policy: governed
review_required: false
gated: false
confidence:
  source_reliability: A
  info_credibility: 1
provenance:
  - source: "Internal methodology (Artifact A §4.4)"
    retrieved: 2026-05-27
    note: "primary"
last_verified: 2026-05-27
---
# House Point of View — The Strawman Stance

## The model
We do not ask a client "what is your process?" because the honest answer is often nothing, partial, or a polite fiction. We arrive with a populated strawman — a defensible default based on the client's industry, size, and opening signals — and invite objections. The objections become the requirements.

## When it applies
Every client engagement. Especially clients with uneven structure (executives have a system; marketing runs on vibes; delivery lives in someone's head).

## When it doesn't
When a client has a genuinely mature, documented, working system — then we audit and reconcile rather than lead with a strawman. This is the brownfield case (see [[audit]]).

## Worked example
A client "has a sales process" but it's three sticky notes and a gut feel. Rather than spending a discovery cycle extracting a process that isn't there, we present the industry-standard sales motion as a strawman. The client says "we don't qualify that way, we do X." That sentence is a requirement we'd never have gotten by asking "what's your process?" The absence of structure became an asset.

## Why this is the moat
Whether the client knows it or not, arriving with a defensible point of view adds value and positions us as bringing thought leadership rather than extracting unpaid consulting from the client. It turns the most common blocker into the engine of the engagement.
