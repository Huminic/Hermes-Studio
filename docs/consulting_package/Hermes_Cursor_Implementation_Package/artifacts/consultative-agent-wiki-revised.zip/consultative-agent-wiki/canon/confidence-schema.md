---
id: confidence-schema
type: reference
title: Confidence Schema (Admiralty Code)
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon, invariant, confidence]
links: [house-canon-index, challenge-loop]
edit_policy: locked
review_required: false
gated: false
authority: canonical
---
# Confidence Schema — NATO Admiralty Code

Two axes. Every strategic-knowledge claim carries both. Outputs propagate the rating into their framing.

## Source reliability (who told you)
- A — Completely reliable
- B — Usually reliable
- C — Fairly reliable
- D — Not usually reliable
- E — Unreliable
- F — Reliability cannot be judged

## Information credibility (how true it is)
- 1 — Confirmed by independent sources
- 2 — Probably true
- 3 — Possibly true
- 4 — Doubtful
- 5 — Improbable
- 6 — Truth cannot be judged

## Usage
A claim rated **B2** = "usually-reliable source, probably true."

The agent's output MUST describe what the rating says, never perform certainty beyond it. Correct: "I found X (B2) and Y (D4); these *suggest* Z, worth verifying." Incorrect: "Z is the case." This is the structural fix for overconfident findings (the auto-dealer anti-pattern).

## Tactical alternative
Tactical knowledge uses `authority: canonical | under-review | deprecated` instead of graded confidence. A procedure is authoritative or it is being replaced; it does not need a credibility grade.
