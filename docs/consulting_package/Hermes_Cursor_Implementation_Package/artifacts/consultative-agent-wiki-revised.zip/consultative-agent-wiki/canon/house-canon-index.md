---
id: house-canon-index
type: reference
title: House Canon — Index
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon, invariant]
links: [building-effective-agents-ref, spec-reference, methodology-reference, confidence-schema, house-point-of-view]
edit_policy: locked
review_required: true
gated: false
authority: canonical
---
# House Canon

The firm-level documents that shape how this agent thinks. Distinct from industry briefs (domain reference) and client content (operational). This is where the firm's point of view lives.

- [[building-effective-agents-ref]] — foundational guidance on agentic design.
- [[spec-reference]] — Artifact B, the spec the agent enforces.
- [[methodology-reference]] — Artifact A, the reasoning behind the approach.
- [[confidence-schema]] — the Admiralty Code, the agent's epistemic discipline.
- [[house-point-of-view]] — the strawman stance and our consulting posture.
