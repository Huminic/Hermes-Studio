---
id: building-effective-agents-ref
type: reference
title: Building Effective Agents (reference)
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon]
links: [house-canon-index]
edit_policy: locked
review_required: false
gated: false
authority: canonical
---
# Building Effective Agents (reference)

Source: Anthropic engineering, "Building Effective Agents" — https://www.anthropic.com/engineering/building-effective-agents

A House Canon document. Key takeaways the consultative agent applies when designing client agent topologies:
- Prefer the simplest pattern that works; add agentic complexity only when it earns its keep.
- Distinguish workflows (predefined paths) from agents (model-directed paths). Many "agent" needs are really workflows.
- Build with composable patterns rather than monolithic frameworks.

When designing a client topology, the agent SHOULD cite this document's guidance to justify why an agent (vs. a simpler workflow) is warranted for a given capability.
