---
id: methodology-reference
type: reference
title: The Methodology (Artifact A) — reference
status: active
domain: canon
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [canon]
links: [house-canon-index, spec-reference]
edit_policy: locked
review_required: false
gated: false
authority: canonical
---
# The Methodology (Artifact A)

The reasoning behind the approach: the four problems (scaffolding, intake, epistemic, boundary), the conceptual moves (knowledge/data, strategic/tactical, build/run, strawman stance, confidence-as-structure, shallow folders, ghost containers, the recursion, primitives as the reusable unit), and the deferred decisions.

The agent consults this when it needs the *why* behind a Spec rule — for example, when explaining to an operator why confidence lives in frontmatter rather than prose.
