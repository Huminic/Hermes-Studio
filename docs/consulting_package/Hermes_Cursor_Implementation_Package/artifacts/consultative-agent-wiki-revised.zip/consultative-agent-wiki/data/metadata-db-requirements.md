---
id: metadata-db-requirements
type: data-contract
title: Data Brain / Metadata DB Requirements
status: active
domain: data
created: 2026-05-27
updated: 2026-05-28
owner: role:platform-architect
tags: [data, metadata]
links: [wiki-semantic-agent-template, database-semantic-agent-template, knowledge-data-interaction-contract]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Data Brain / Metadata DB Requirements

The always-on substrate for the operational layer. At minimum, every wiki interaction is recorded, but the Data Brain is broader than a wiki audit log. This page defines *what must be recorded* at the contract level, not the physical schema.

## Output description
The minimum operational record families required for a conformant Data Brain contract:
- wiki interaction records
- runtime event records
- task and work-object state
- projected current state where needed
- retrieval context snapshots
- reconciliation items
- report and output records
- source-reference lineage

## Destination
The per-client Data Brain / metadata database, governed by the database semantic agent.

## Shape (minimum captures)
### Wiki interaction records
- actor (role + human/agent token identity)
- action (read / create / update / deprecate / archive)
- target page id + version before/after
- timestamp
- reason (for governed edits)
- gate event reference (if the action was gated)

### Runtime operational records
- event class
- affected object or entity id
- tenant / org scope
- action timestamp
- initiating actor or agent
- relevant source references
- confidence or reconciliation status where applicable

### Retrieval snapshots
- requesting agent or workflow
- context bundle identifier
- source set used
- timestamp
- downstream action or output reference if one was produced

## Write guarantees
Append-only for audit and event trails; derived projections are updated separately.

## Logging expectations
Sufficient to answer:
- what changed in this wiki since X, and on whose authority;
- what runtime events occurred for this org or workflow;
- what context an agent used when making an operational decision;
- what contradictions or low-confidence outputs entered reconciliation.
