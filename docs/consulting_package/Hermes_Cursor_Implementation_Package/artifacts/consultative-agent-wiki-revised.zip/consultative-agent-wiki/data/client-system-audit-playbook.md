---
id: client-system-audit-playbook
type: integration-playbook
title: Client System Audit Integration Playbook
status: active
domain: data
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [integration, audit]
links: [audit, consultative-agent-scope-contract, approval-matrix]
edit_policy: governed
review_required: false
gated: false
authority: canonical
last_verified: 2026-05-27
---
# Client System Audit Integration Playbook

## System overview
Reading a client's existing materials (Notion, Drive, Confluence, CRMs) during the brownfield audit.

## Auth model
Read-only access granted by the client. The agent never creates accounts or authorizes password access on the client's behalf.

## Access pattern
Inventory first, then read targeted. Default to read-only; any write requires operator sign-off per [[approval-matrix]].

## Known pitfalls
- Stated structure often diverges from real usage — corroborate documents against observed behavior.
- Cryptic systems (e.g., CRMs requiring opaque-ID HTTP retrieval) → author a dedicated integration playbook for that system in the *client* wiki.

## Failure modes
- Access denied / missing → log as input request; do not fabricate.

## Rate / latency notes
N/A — bounded by the audit scope.

## Owner
role:platform-architect
