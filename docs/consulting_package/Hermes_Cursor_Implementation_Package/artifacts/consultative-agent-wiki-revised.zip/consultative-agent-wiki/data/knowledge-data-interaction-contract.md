---
id: knowledge-data-interaction-contract
type: policy
title: Knowledge Brain ↔ Data Brain Interaction Contract
status: active
domain: data
created: 2026-05-28
updated: 2026-05-28
owner: role:platform-architect
tags: [data, knowledge-brain, data-brain, interaction-contract]
links: [metadata-db-requirements, consultative-agent-scope-contract, authoring-governance-policy, human-relay-specification]
edit_policy: governed
review_required: true
gated: false
authority: canonical
---
# Knowledge Brain ↔ Data Brain Interaction Contract

This page states the operating boundary between the consultative system's two pillars.

## The rule
- The **Knowledge Brain** is the canonical markdown/wiki layer.
- The **Data Brain** is the structured operational layer.
- Runtime agents may read from both.
- Runtime may write operational records to the Data Brain through governed paths.
- Runtime does not silently rewrite canonical wiki content by default.

## What belongs in the Knowledge Brain
- workflows
- blueprints
- rationale
- policies
- scope contracts
- reporting requirements
- human-readable operating context
- strawman defaults
- methodological and canonical references

## What belongs in the Data Brain
- event records
- task and work-object state
- projected current state
- transactions and operational outputs
- retrieval context snapshots
- reconciliation items
- source-linked runtime observations
- audit and change records

## Runtime writeback rule
Runtime may create:
- events
- observations
- report outputs
- task/state updates
- suggested knowledge changes
- reconciliation items
- draft narrative updates

Runtime must not silently alter canonical knowledge. Proposed knowledge-layer changes flow through drafts, inboxes, suggested updates, or explicit governance review.

## Contradictions
If the narrative layer and operational layer appear to disagree:
- surface the contradiction,
- preserve lineage to both sides,
- create a reconciliation item when the conflict affects execution or reporting,
- do not let one layer silently overwrite the other.

## Reporting rule
Report requirements, templates, schedules, recipients, thresholds, and governance belong in the Knowledge Brain.
Generated reports, delivery events, and execution traces belong in the Data Brain or associated operational output stores.

## Source-reference rule
Any structured record derived from wiki or source material should preserve enough lineage to trace back to the originating page or source reference.
