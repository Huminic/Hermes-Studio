---
id: web-research-playbook
type: integration-playbook
title: Web Research Integration Playbook
status: active
domain: data
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [integration, research]
links: [industry-onboarding-protocol, confidence-schema]
edit_policy: governed
review_required: false
gated: false
authority: canonical
last_verified: 2026-05-27
---
# Web Research Integration Playbook

## System overview
The agent's web search/fetch capability, used during Industry Onboarding and audit.

## Auth model
Handled by the platform; the agent never stores credentials.

## Access pattern
Search broad → narrow; fetch full pages for anything cited. Rate every source on the Admiralty scale before use (see [[confidence-schema]]).

## Known pitfalls
- SEO-optimized content ranks high but may be low-credibility — rate accordingly.
- Never reproduce substantial copyrighted content; extract patterns and facts only.

## Failure modes
- No authoritative source found → mark claims provisional (F/6) and escalate if the brief can't reach confidence.

## Rate / latency notes
Scale searches to task complexity; prefer original sources over aggregators.

## Owner
role:platform-architect
