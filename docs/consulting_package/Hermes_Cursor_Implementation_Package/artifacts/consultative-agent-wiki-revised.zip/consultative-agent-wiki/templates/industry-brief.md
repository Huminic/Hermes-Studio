---
id: industry-[name]-brief
type: industry-brief
title: [Industry] Brief
status: active
domain: industry-reference
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: [industry-brief]
links: []
edit_policy: governed
review_required: false
gated: false
confidence:
  source_reliability: [A-F]
  info_credibility: [1-6]
provenance: []
last_verified: [YYYY-MM-DD]
---
# [Industry] Brief
## Canonical frameworks
## Best-practice sources
## Regulatory / compliance shape
## Common operational domains
## Industry vocabulary
## Case patterns
## Overall confidence
