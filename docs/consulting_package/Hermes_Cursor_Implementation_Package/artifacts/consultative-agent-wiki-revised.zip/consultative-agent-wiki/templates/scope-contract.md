---
id: [agent-name]-scope-contract
type: scope-contract
title: [Agent Name] Scope Contract
status: active
domain: governance
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: [invariant, scope]
links: []
edit_policy: governed
review_required: true
gated: false
---
# [Agent Name] Scope Contract
## Owns end-to-end
## Proposes, does not execute
## Must escalate
## Must never touch
## Human owns
