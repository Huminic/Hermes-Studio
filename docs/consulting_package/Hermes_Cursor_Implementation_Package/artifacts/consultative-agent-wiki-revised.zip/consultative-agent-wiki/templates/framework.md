---
id: [kebab-id]
type: framework
title: [Title]
status: active
domain: [domain]
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: []
links: []
edit_policy: governed
review_required: false
gated: false
confidence:
  source_reliability: [A-F]
  info_credibility: [1-6]
provenance:
  - source: "[source]"
    retrieved: [YYYY-MM-DD]
    note: "[note]"
last_verified: [YYYY-MM-DD]
---
# [Title]
## The model
## When it applies
## When it doesn't
## Worked example
