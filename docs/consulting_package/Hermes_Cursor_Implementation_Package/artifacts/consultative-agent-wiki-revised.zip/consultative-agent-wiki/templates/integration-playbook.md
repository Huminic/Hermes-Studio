---
id: [kebab-id]
type: integration-playbook
title: [System] Integration Playbook
status: active
domain: [domain]
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: [integration]
links: []
edit_policy: governed
review_required: false
gated: false
authority: canonical
last_verified: [YYYY-MM-DD]
---
# [System] Integration Playbook
## System overview
## Auth model
## Access pattern
## Known pitfalls
## Failure modes
## Rate / latency notes
## Owner
