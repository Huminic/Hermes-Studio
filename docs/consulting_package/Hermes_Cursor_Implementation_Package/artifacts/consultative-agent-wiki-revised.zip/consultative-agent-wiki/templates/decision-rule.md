---
id: [kebab-id]
type: decision-rule
title: [Title]
status: active
domain: [domain]
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: []
links: []
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# [Title]
## Inputs
## Logic
## Edge cases
## Default / fallback
