---
id: ghost-[what]-[domain]
type: ghost
title: "(Ghost) [What]"
status: draft
domain: [domain]
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: [ghost]
links: []
edit_policy: open
review_required: false
gated: false
---
# Ghost container: [What]
Nothing exists here yet. A [primitive type] belongs here when [condition]. Trigger for creation: [event].
