---
id: [kebab-id]
type: procedure
title: [Title]
status: active
domain: [domain]
created: [YYYY-MM-DD]
updated: [YYYY-MM-DD]
owner: role:[role]
tags: []
links: []
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# [Title]
## Preconditions
- [..]
## Steps
1. [..]
## Postconditions
- [..]
## Failure handling
- [inline or link to runbook]
## Owner
role:[role]
