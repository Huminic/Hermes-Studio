---
id: human-relay-specification
type: reference
title: Human Relay Specification
status: active
domain: governance
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [invariant, relay]
links: [approval-matrix, consultative-agent-scope-contract, challenge-loop]
edit_policy: governed
review_required: true
gated: false
authority: canonical
---
# Human Relay Specification

Where the consultative agent must pause for a human. Three categories, distinguished because they need different handling.

## Approval gates (tactical, binary)
The agent has done X and needs sign-off for Y. Enumerated in [[approval-matrix]]. For this agent the principal gates are:
- Marking a readiness gate as passed (operator certifies).
- Finalizing the deployment topology decision.
- Packaging for handoff.

## Input requests (informational; treated as smells)
The agent needs information it cannot obtain itself (e.g., a client credential, a missing system access, an undocumented process detail). Each input request MUST be logged with the gap it reveals, so the gap can be closed permanently rather than recurring. Recurring input requests of the same kind signal a missing integration playbook or a missing strawman default.

## Feedback loops (after-the-fact)
The operator corrects or rates the agent's output. The loop MUST close:
- Feedback is logged (destination: metadata DB, category `consultative-feedback`).
- Reviewed on a defined cadence (default: per-engagement retrospective).
- Validated feedback becomes a wiki edit (a refined strawman, a new case, a tightened procedure) via [[authoring-governance-policy]].

## Strategic note
When the agent advises rather than acts (e.g., recommending an approach), the relay is *consultation* — the agent proposes with confidence annotations and the operator decides. It does not seek "approval" for an opinion; it surfaces the opinion with its rating attached.
