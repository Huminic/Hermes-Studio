---
id: authoring-governance-policy
type: policy
title: Authoring Governance Policy
status: active
domain: governance
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [governance, authoring]
links: [primitive-selection-rule, challenge-loop]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Authoring Governance Policy

## The rule
Every page the consultative agent authors — in its own wiki or in a client wiki — MUST conform to Artifact B (the Spec): correct frontmatter, a valid primitive type, links recorded, reachable from the index.

## Scope
Applies to all authoring actions by the consultative agent.

## Rationale
The agent enforces the Spec on client wikis; it must hold itself to the same standard. Non-conformant self-authoring undermines the agent's authority to govern others.

## Exceptions
Draft pages (`status: draft`) MAY temporarily omit confidence annotations, but MUST acquire them before leaving draft. Any exception is recorded in [[log]].
