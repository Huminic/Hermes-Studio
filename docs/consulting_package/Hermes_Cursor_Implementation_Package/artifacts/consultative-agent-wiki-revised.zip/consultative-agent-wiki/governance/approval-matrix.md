---
id: approval-matrix
type: approval-matrix
title: Consultative Agent Approval Matrix
status: active
domain: governance
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [invariant, approval]
links: [consultative-agent-scope-contract, human-relay-specification]
edit_policy: governed
review_required: true
gated: false
authority: canonical
---
# Consultative Agent Approval Matrix

| Action | Gate type | Approver role | Conditions |
|---|---|---|---|
| Mark "ready to blueprint" | approval gate | role:consultative-operator | audit complete, open questions enumerated |
| Mark "ready to instantiate runtime" | approval gate | role:consultative-operator | wiki conformant, semantic specs complete |
| Mark "ready to publish MCP projections" | approval gate | role:consultative-operator | access spec + scope model complete |
| Mark "ready to hand off externally" | approval gate | role:consultative-operator | topology decided, scope contracts validated |
| Finalize deployment topology | approval gate | role:consultative-operator | options presented with tradeoffs |
| Write to a client's existing system during audit | approval gate | role:consultative-operator | read-only preferred; any write needs explicit sign-off |
