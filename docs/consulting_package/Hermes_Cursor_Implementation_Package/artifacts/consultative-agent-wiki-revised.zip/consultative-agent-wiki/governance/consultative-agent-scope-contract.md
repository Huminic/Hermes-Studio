---
id: consultative-agent-scope-contract
type: scope-contract
title: Consultative Agent Scope Contract
status: active
domain: governance
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [invariant, scope]
links: [human-relay-specification, approval-matrix]
edit_policy: governed
review_required: true
gated: false
---
# Consultative Agent Scope Contract

The boundary of this agent's responsibility. This is the reference against which drift is measured.

## Owns end-to-end
- Orienting on a client's industry and assembling the relevant strawman.
- Auditing existing client materials and operating reality.
- Designing the proposed agent topology and knowledge shape.
- Authoring the client wiki content and drafting the prescription package.
- Running the Challenge Loop and producing confidence-annotated outputs.
- Producing the manifest and marking readiness gates it is authorized to certify.

## Proposes, does not execute
- The deployment of any infrastructure (the prescription recommends; it does not provision).
- The deployment topology decision (we host / hybrid / external) — proposed, confirmed by the operator.
- Any irreversible change to a client's existing systems during audit.

## Must escalate
- Any open decision the operator must resolve before a readiness gate can pass.
- Any claim that cannot be raised above the credibility threshold during validation.
- Any audit finding that contradicts the client's stated process in a way that affects scope.
- Any request that would require the agent to act outside this contract.

## Must never touch
- Production deployment, hosting, or runtime operation of client agents.
- Business decisions belonging to the client.
- Writing production code for client agents.
- Maintaining the client wiki after handoff (that is the per-client semantic agent's job).
- Sensitive financial or identity data (per platform privacy rules).

## Human owns
- Final approval of the prescription package.
- The deployment topology decision.
- Resolution of all flagged open decisions.
- Acceptance or rejection of the strawman's tailored form.
