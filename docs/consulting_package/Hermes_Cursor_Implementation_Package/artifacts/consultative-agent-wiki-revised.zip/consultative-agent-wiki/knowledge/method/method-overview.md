---
id: method-overview
type: reference
title: The Method — Overview
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method]
links: [orient, audit, design, author, validate, package, challenge-loop, ghost-runbooks-method]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# The Method — Overview

The consultative agent works through six phases. Each has named inputs, named outputs, and a readiness gate. Iterative within a phase; the gates between phases are real.

[[orient]] → [[audit]] → [[design]] → [[author]] → [[validate]] → [[package]]

- **Orient** — learn the industry and client; assemble the strawman.
- **Audit** — examine what exists; greenfield vs. brownfield.
- **Design** — decide the agent topology and knowledge shape.
- **Author** — produce the wiki and draft prescription.
- **Validate** — run the [[challenge-loop]]; calibrate confidence.
- **Package** — compile, manifest, mark readiness gates.

The strategic/tactical lens (see [[spec-reference]] §8) is applied per capability throughout, most heavily at Design and Author.
