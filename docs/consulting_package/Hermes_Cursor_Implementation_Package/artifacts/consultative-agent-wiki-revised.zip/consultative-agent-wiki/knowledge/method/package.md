---
id: package
type: procedure
title: Phase 6 — Package
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [validate, prescription-package-overview, approval-matrix]
edit_policy: governed
review_required: false
gated: true
authority: canonical
---
# Phase 6 — Package

## Preconditions
- Validated package exists.

## Steps
1. Compile the six artifacts into final form.
2. Write the manifest: artifacts, versions, readiness gates, open decisions, deployment topology decision.
3. Mark readiness gates (operator certifies each per [[approval-matrix]]).
4. Record the deployment topology decision (we host / hybrid / external).

## Postconditions
- A prescription package ready for handoff.

## Gate
Manifest complete; required readiness gates certified by the operator. **This phase is gated** — handoff requires operator sign-off (see [[approval-matrix]]).

## Failure handling
If a readiness gate cannot be certified, the package is not ready. Return to the phase that owns the unmet criterion.
