---
id: design
type: procedure
title: Phase 3 — Design
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [audit, author, primitive-selection-rule, folder-grouping-rule, prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Phase 3 — Design

## Preconditions
- Orientation brief and audit findings complete.

## Steps
1. Decide the agent topology: which agents, doing what.
2. For each proposed agent, apply the strategic/tactical lens (see [[spec-reference]] §8).
3. Draft each agent's scope contract (owns / proposes / escalates / never / human-owns).
4. Identify each agent's tool boundaries, human relays, and the external systems it touches (→ integration playbooks needed).
5. Identify each agent's data reads and writes.
6. Choose the wiki's folder grouping dimension via [[folder-grouping-rule]].
7. For each capability, pre-select the primitives to author via [[primitive-selection-rule]].

## Postconditions
- An agentic design document exists.

## Gate
Every proposed agent has a draft scope contract and a named character (strategic / tactical / mix).

## Failure handling
If two agents have overlapping scope, resolve the boundary before proceeding — overlap is a deployment failure waiting to happen.
