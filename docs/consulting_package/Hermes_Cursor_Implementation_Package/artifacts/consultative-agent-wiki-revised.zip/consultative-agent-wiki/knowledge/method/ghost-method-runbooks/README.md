---
id: ghost-runbooks-method
type: ghost
title: "(Ghost) Method Runbooks"
status: draft
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [ghost]
links: []
edit_policy: open
review_required: false
gated: false
---
# Ghost container: Method Runbooks
No runbooks exist yet for the agent's own method. A runbook belongs here when a method phase fails in a way that needs documented recovery beyond its inline failure handling. Trigger: the first time a phase fails in a recurring way.
