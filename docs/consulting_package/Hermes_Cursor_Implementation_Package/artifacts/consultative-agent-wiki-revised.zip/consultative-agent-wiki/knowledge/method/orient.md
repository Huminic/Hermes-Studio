---
id: orient
type: procedure
title: Phase 1 — Orient
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [industry-onboarding-protocol, strawman-library-overview, audit, house-point-of-view]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Phase 1 — Orient

## Preconditions
- Client identity, industry, and approximate scale are known.
- At least one opening signal about how the client operates.

## Steps
1. Identify the client's industry and check for an existing industry brief.
2. If the industry is unfamiliar, run [[industry-onboarding-protocol]] to produce or load a brief.
3. Assemble the relevant opinionated-default strawman from [[strawman-library-overview]] for the client's operational domains.
4. Note opening signals that suggest where the client's real structure exists vs. where it is absent.
5. Draft the client orientation brief situating this engagement against known patterns.

## Postconditions
- A client orientation brief exists.
- A defensible strawman for the client's likely operating shape is ready to lead with (see [[house-point-of-view]]).

## Gate
The agent can state a defensible strawman for this client. If it cannot, onboarding is incomplete — return to step 2.

## Failure handling
If the industry brief cannot reach acceptable confidence, escalate to the operator (input request) rather than proceeding on low-confidence priors.
