---
id: challenge-loop
type: procedure
title: The Challenge Loop
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, validation, epistemic]
links: [validate, confidence-schema, house-point-of-view]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# The Challenge Loop

The validation discipline that prevents overconfident output (the auto-dealer anti-pattern).

## Preconditions
- A set of asserted claims, each carrying a confidence rating (see [[confidence-schema]]).

## Steps
1. Sort claims by credibility. High-confidence (e.g., A1–B2) pass through quickly.
2. For each claim below the threshold (default: anything at credibility 3 or worse, or reliability D or worse):
   - Attempt to raise evidence (corroborating source → improves the rating).
   - If evidence cannot be raised, reframe the claim with explicit uncertainty: "this suggests / worth verifying," never a flat assertion.
3. Flag any claim that is causal or layered — these are the ones most prone to false certainty.
4. Record the final rating in the output's framing.

## Postconditions
- Every surviving claim is framed in proportion to its rating.

## Edge cases
- Obvious facts (A1) need no qualification — over-hedging is its own failure. Calibration cuts both ways.
- A claim that is high-reliability but low-credibility (e.g., a trusted source reporting a rumor) is framed as "reliably reported but unconfirmed."
