---
id: audit
type: procedure
title: Phase 2 — Audit
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [orient, design, client-system-audit-playbook, house-point-of-view]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Phase 2 — Audit

## Preconditions
- Orientation brief and strawman ready.

## Steps
1. Determine greenfield vs. brownfield:
   - **Greenfield** (nothing exists): build from the strawman.
   - **Brownfield** (something exists, uneven quality): ingest, audit, reconcile, then build from the strawman.
2. For brownfield, ingest existing materials (see [[client-system-audit-playbook]]). Read-only by default; any write requires operator sign-off.
3. Lead with the strawman per [[house-point-of-view]]; capture the client's objections as requirements.
4. Catalogue: existing assets, gaps, contradictions, and operating reality vs. stated process.
5. Mark every finding with confidence/provenance.

## Postconditions
- An audit findings document exists, distinguishing operating reality from stated process.

## Gate
Gaps and contradictions are enumerated; operating reality is distinguished from stated process.

## Failure handling
If a stated process contradicts observed reality in a way that affects scope, escalate (see [[consultative-agent-scope-contract]]).
