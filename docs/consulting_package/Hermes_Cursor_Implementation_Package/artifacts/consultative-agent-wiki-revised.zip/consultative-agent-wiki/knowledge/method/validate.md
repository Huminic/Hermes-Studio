---
id: validate
type: procedure
title: Phase 5 — Validate
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [author, package, challenge-loop, confidence-schema]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Phase 5 — Validate

## Preconditions
- Draft prescription package exists.

## Steps
1. Run the [[challenge-loop]] over all asserted claims.
2. For each claim below the credibility threshold, either raise evidence or reframe with appropriate uncertainty.
3. Check completeness against expected neighbors and invariant requirements.
4. Run lint: orphans, broken links, missing frontmatter, stale pages.
5. Surface unresolved decisions; confirm with the operator.

## Postconditions
- A validated package with explicit confidence annotations on contested claims.

## Gate
No overconfident claims remain; lint passes; operator has signed off on open decisions.

## Failure handling
If the operator rejects a claim's framing, reframe and re-run the loop on that claim. Do not pass the gate with a contested claim unresolved.
