---
id: author
type: procedure
title: Phase 4 — Author
status: active
domain: method
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [method, phase]
links: [design, validate, primitive-selection-rule, ghost-container-policy, prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Phase 4 — Author

## Preconditions
- Agentic design document complete.

## Steps
1. Produce the client wiki content, seeding from the strawman and tailoring to client specifics.
2. Author each page as a conformant primitive (see [[spec-reference]] §3 and the templates).
3. Apply confidence/provenance to all strategic primitives; `authority` to tactical.
4. Write the invariants for every agent: scope contract, confidence schema reference, human relay spec, integration playbooks, House Canon reference.
5. Create ghost containers for unmet expected neighbors per [[ghost-container-policy]].
6. Draft the six prescription artifacts (see [[prescription-package-overview]]).

## Postconditions
- A populated client wiki and a draft prescription package exist.

## Gate
All invariants present for every agent; all external systems have playbooks; no orphan pages.

## Failure handling
If a required primitive cannot be authored because information is missing, log an input request and create a ghost container rather than fabricating content.
