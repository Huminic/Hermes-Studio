---
id: industry-onboarding-protocol
type: runbook
title: Industry Onboarding Protocol
status: active
domain: industry-onboarding
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [onboarding, runbook]
links: [orient, confidence-schema, industry-ai-smb-ops-brief, web-research-playbook, ghost-industry-case-library]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Industry Onboarding Protocol

A runbook the agent executes against itself before engaging an unfamiliar industry. Output: an industry brief, reusable across all clients in that industry.

## Symptoms (when to run)
- A client is in an industry with no existing brief, or a brief below acceptable confidence.

## Steps
1. Draw on training knowledge to sketch the industry; mark each claim provisional (typically F/6 until corroborated).
2. Search for established best-practice frameworks and standards bodies; rate each source on the Admiralty scale (see [[confidence-schema]]).
3. Identify and summarize relevant case studies; extract transferable patterns (never reproduce substantial copyrighted content).
4. Where high-value talks/material exist, transcribe and extract patterns and facts only.
5. Identify the common operational domains and their typical structure.
6. Build the vocabulary mapping for industry-specific terms.
7. Note regulatory/compliance shape.
8. Assign an overall confidence rating to the brief.

## Recovery / escalation
- If the brief cannot reach acceptable confidence after research, escalate to the operator (input request) rather than proceeding on weak priors.

## Expected neighbors
Strawman shapes per operational domain, vocabulary entries, common-integration list, compliance constraints.

## Ghost containers
Industry case library, anti-pattern catalogue, common stakeholder map.
