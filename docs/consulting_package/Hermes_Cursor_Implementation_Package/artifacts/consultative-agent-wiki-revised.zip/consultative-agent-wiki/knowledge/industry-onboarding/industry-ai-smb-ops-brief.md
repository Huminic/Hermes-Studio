---
id: industry-ai-smb-ops-brief
type: industry-brief
title: Industry Brief — AI Agent Deployment for SMB Operations
status: active
domain: industry-reference
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [industry-brief]
links: [industry-onboarding-protocol, strawman-library-overview]
edit_policy: governed
review_required: false
gated: false
confidence:
  source_reliability: B
  info_credibility: 2
provenance:
  - source: "Internal methodology + Anthropic agent guidance"
    retrieved: 2026-05-27
    note: "primary"
last_verified: 2026-05-27
---
# Industry Brief — AI Agent Deployment for SMB Operations

The consultative agent's own industry. Authored first, per the Spec, as a dogfooding example.

## Canonical frameworks
- EOS / Traction (Gino Wickman) — common in SMB executive teams (B2).
- RevOps norms for sales/marketing alignment (C2).
- ITIL-lite for service-delivery shops (C3).

## Best-practice sources
- Anthropic, "Building Effective Agents" (A1) — agent vs. workflow distinction.
- Karpathy LLM wiki pattern (B2) — agent-readable knowledge.

## Regulatory / compliance shape
- Varies by sub-vertical; data-handling and PII rules apply broadly. Verify per client.

## Common operational domains
Client delivery, sales, marketing/ads, finance, hiring, executive cadence. Most SMBs have structure in 1–2 of these and vibes in the rest (B2) — this unevenness is the core intake reality.

## Industry vocabulary
"Process" often means "a few sticky notes." "System" may mean a single SaaS tool. Map these per client via vocabulary entries.

## Case patterns
- Pattern: client claims a documented process; audit reveals it lives in one person's head. Treat as brownfield-with-gaps.
- Pattern: executive layer is structured (EOS), operational layer is not. Lead with strawman on the operational layer.

## Overall confidence
B2 — usually-reliable internal synthesis, probably accurate; refine after first engagements.
