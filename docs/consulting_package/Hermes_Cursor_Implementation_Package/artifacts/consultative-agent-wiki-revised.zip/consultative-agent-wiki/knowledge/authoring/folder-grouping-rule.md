---
id: folder-grouping-rule
type: decision-rule
title: Folder Grouping Rule
status: active
domain: authoring
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [authoring, decision-rule]
links: [design, spec-reference]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Folder Grouping Rule

How the agent chooses the single folder grouping dimension for a wiki (Spec §2.4: shallow folders, metadata does the work).

## Inputs
The set of agents/capabilities and the humans who will maintain the wiki.

## Logic
- Pick the dimension that most aids the maintainers: by domain, by capability, by client, or by lifecycle stage.
- Choose exactly one. Do not encode multiple dimensions in the tree — that is what tags and links are for.
- Keep depth ≤ 3 below root.

## Edge cases
- If two dimensions seem equally useful, choose the one the maintainers name first when describing the wiki out loud.

## Default / fallback
Default to **by capability** for agent wikis (as this wiki itself does).
