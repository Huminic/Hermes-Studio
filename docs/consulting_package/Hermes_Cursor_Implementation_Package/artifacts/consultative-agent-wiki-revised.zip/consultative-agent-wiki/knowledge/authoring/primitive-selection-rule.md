---
id: primitive-selection-rule
type: decision-rule
title: Primitive Selection Rule
status: active
domain: authoring
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [authoring, decision-rule]
links: [author, spec-reference]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Primitive Selection Rule

How the agent decides which primitive to author for a given piece of knowledge.

## Inputs
A unit of knowledge to capture, and its intended use.

## Logic
- Is it read to *decide* or written to *record*? Decide → Knowledge primitive. Record → Data primitive.
- Multi-step task to perform reliably → **procedure**.
- Choice between options under conditions → **decision-rule**.
- Shape of structured data → **schema**.
- How to talk to a specific external system → **integration-playbook**.
- Failure recovery → **runbook**.
- A mental model for advising → **framework**.
- A real episode with lessons → **case**.
- A specific named thing → **entity-profile**.
- A defined idea → **concept**.
- A stable fact/table → **reference**.
- A rule governing many actions → **policy**.
- A client term needing mapping → **vocabulary-entry**.

## Edge cases
- If a page wants to be two primitives, split it (Spec §2.1).
- If unsure between framework and concept: framework is *applied*, concept is *defined*.

## Default / fallback
When genuinely ambiguous, prefer the more specific primitive and link liberally.
