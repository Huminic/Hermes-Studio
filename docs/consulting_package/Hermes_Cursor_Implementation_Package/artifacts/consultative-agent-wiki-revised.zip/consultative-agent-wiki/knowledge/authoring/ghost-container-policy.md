---
id: ghost-container-policy
type: policy
title: Ghost Container Policy
status: active
domain: authoring
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [authoring, ghost]
links: [author, primitive-selection-rule]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Ghost Container Policy

## The rule
When authoring, for each primitive's expected neighbors (Spec §3) that do not yet exist, create a ghost container: an empty folder with only a README stating what belongs there and what triggers its creation.

## Scope
All authoring, in this wiki and client wikis.

## Rationale
Makes the possibility space discoverable without polluting the wiki with empty content. Gives the agent a completeness checklist and prevents silent omission.

## Exceptions
Do not create ghosts for neighbors that are genuinely irrelevant to the deployment. A ghost asserts "this could plausibly exist here," not "every primitive type must appear everywhere."
