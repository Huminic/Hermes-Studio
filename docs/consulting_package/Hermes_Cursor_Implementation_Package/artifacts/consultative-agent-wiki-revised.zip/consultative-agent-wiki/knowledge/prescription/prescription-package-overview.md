---
id: prescription-package-overview
type: reference
title: Prescription Package — Overview
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription]
links: [agentic-design-template, data-storage-template, mcp-access-template, wiki-semantic-agent-template, database-semantic-agent-template, manifest-template]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Prescription Package — Overview

The consultative agent's deliverable: six artifacts plus a manifest, handed to whoever deploys.

1. **Client wiki** — built per the Spec, populated with client specifics.
2. [[agentic-design-template]] — the agents to deploy.
3. [[data-storage-template]] — sources, APIs, outputs, federation.
4. [[mcp-access-template]] — scopes, tokens, access rules.
5. [[wiki-semantic-agent-template]] — per-client wiki governor.
6. [[database-semantic-agent-template]] — per-client data governor.

Plus [[manifest-template]] — the package manifest with readiness gates and topology decision.

## Minimum vs. maximum engagement
- **Minimum:** deliver + host the wiki layer, its semantic agent, and MCP access.
- **Maximum:** the above plus deployed agent shapes and the data stores they write to.
Same package shape either way; the topology decision in the manifest records which.
