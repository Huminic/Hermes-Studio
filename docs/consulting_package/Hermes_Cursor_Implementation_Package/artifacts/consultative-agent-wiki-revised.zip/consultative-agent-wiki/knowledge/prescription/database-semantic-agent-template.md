---
id: database-semantic-agent-template
type: schema
title: Database Semantic Agent Spec (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, semantic-agent]
links: [prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Database Semantic Agent Spec (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Sections
- **Governed layer**: the metadata / output database
- **Responsibilities**: CRUD mediation, access enforcement, audit logging, observability
- **Permission model**: shared with the wiki layer (one policy engine — same roles, scopes, audit)
- **Write guarantees**: [..]
