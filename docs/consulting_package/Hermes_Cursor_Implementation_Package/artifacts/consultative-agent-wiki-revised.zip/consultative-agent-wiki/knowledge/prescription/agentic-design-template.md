---
id: agentic-design-template
type: schema
title: Agentic Design Prescription (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, agentic-design]
links: [prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Agentic Design Prescription (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Per-agent specification
For each proposed agent:
- **Name / purpose**: [..]
- **Character**: tactical / strategic / mix (per capability)
- **Scope contract**: owns / proposes / escalates / never / human-owns
- **Tool boundaries**: [allowed tools]
- **Orchestration**: [where it sits relative to other agents]
- **Cost/latency posture**: [fast-cheap vs. think-expensive]
- **External systems touched**: [→ integration playbooks required]
- **Data reads / writes**: [..]
