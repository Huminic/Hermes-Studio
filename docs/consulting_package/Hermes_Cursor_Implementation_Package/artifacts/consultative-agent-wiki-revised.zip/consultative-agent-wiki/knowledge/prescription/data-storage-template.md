---
id: data-storage-template
type: schema
title: Data-Storage Prescription (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, data-storage]
links: [prescription-package-overview, metadata-db-requirements]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Data-Storage Prescription (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Sections
- **Source systems & APIs to read**: [list, each → integration playbook]
- **Outputs to write & destinations**: [list]
- **Federated vs. pulled vs. pushed**: [the data-movement decisions]
- **Integration playbooks required**: [list]
- **Metadata DB requirement**: what must be recorded about every wiki interaction (always-on). See data/metadata-db-requirements.
