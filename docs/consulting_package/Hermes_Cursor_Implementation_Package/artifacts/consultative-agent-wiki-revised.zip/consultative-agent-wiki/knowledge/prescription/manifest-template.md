---
id: manifest-template
type: schema
title: Prescription Manifest (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, manifest]
links: [prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Prescription Manifest (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Sections
- **Artifacts & versions**: [the six + this manifest]
- **Readiness gates** (each: date + certifying role):
  - ready to blueprint
  - ready to instantiate semantic runtime
  - ready to publish MCP projections
  - ready to hand off externally
- **Open decisions**: [enumerated]
- **Deployment topology decision**: we host / hybrid / external-consumes-projections
