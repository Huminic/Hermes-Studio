---
id: mcp-access-template
type: schema
title: MCP Access Spec (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, mcp-access]
links: [prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# MCP Access Spec (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Sections
- **Scopes**: [the access scopes that exist]
- **Token model**: human token vs. agent token
- **Object-level access rules**: [which roles/agents can CRUD which objects]
- **Wiki access path**: [how agents reach the wiki layer]
- **Data layer access path**: [how agents reach the data layer]
- **History visibility rules**: [who can see change history]
