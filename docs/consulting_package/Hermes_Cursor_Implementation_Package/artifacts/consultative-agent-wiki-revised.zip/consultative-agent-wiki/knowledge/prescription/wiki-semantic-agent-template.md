---
id: wiki-semantic-agent-template
type: schema
title: Wiki Semantic Agent Spec (template)
status: active
domain: prescription
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [prescription, semantic-agent]
links: [prescription-package-overview]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Wiki Semantic Agent Spec (template)

Template for the corresponding artifact in the prescription package. Replace bracketed text per engagement.

## Sections
- **Governed layer**: the client wiki
- **Responsibilities**: enforce edit_policy/review_required; maintain link graph & backlinks; record writes to metadata DB; run lint; surface drift; resolve wikilinks
- **Behavior policy location**: in the client wiki itself (not solely in code)
- **Lint cadence**: [..]
- **Renewal cadences**: tactical quarterly / strategic monthly / per-event
