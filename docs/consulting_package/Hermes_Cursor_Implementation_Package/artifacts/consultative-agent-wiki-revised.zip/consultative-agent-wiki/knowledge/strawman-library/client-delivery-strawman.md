---
id: client-delivery-strawman
type: framework
title: Client Delivery Strawman
status: active
domain: strawman-library
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [strawman, client-delivery]
links: [strawman-library-overview, house-point-of-view]
edit_policy: governed
review_required: false
gated: false
confidence:
  source_reliability: B
  info_credibility: 2
provenance:
  - source: "Common SMB delivery practice"
    retrieved: 2026-05-27
    note: "synthesis"
last_verified: 2026-05-27
---
# Client Delivery Strawman

## The model
A defensible default client-delivery motion to lead with: Intake → Scoping → Kickoff → Execution (with defined checkpoints) → Review → Handoff → Retrospective. Each stage has an owner, an entry condition, and an exit artifact.

## When it applies
SMB service businesses with no documented delivery process, or one that lives in someone's head.

## When it doesn't
Clients with a mature, working, documented delivery system — audit and reconcile instead.

## Worked example
Present this seven-stage motion to a client. They say "we don't do a formal kickoff, we just start." That objection is a requirement: their delivery skips kickoff, which tells you where handoff failures will cluster. Captured without a discovery interview.
