---
id: ghost-marketing-strawman
type: ghost
title: "(Ghost) Marketing Strawman"
status: draft
domain: strawman-library
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [ghost]
links: []
edit_policy: open
review_required: false
gated: false
---
# Ghost container: Marketing Strawman
No marketing strawman authored yet. A framework belongs here when the first client engagement needs a defensible marketing default to lead with. Trigger: first client whose scope includes marketing.
