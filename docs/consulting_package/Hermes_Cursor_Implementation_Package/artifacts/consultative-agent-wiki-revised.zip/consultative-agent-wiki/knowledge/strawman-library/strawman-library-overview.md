---
id: strawman-library-overview
type: reference
title: Strawman Library — Overview
status: active
domain: strawman-library
created: 2026-05-27
updated: 2026-05-27
owner: role:platform-architect
tags: [strawman]
links: [house-point-of-view, client-delivery-strawman, orient, ghost-sales-strawman, ghost-marketing-strawman, ghost-finance-strawman]
edit_policy: governed
review_required: false
gated: false
authority: canonical
---
# Strawman Library — Overview

Opinionated defaults the agent leads with during intake (see [[house-point-of-view]]). One strawman per operational domain. The agent assembles the relevant set during [[orient]] and tailors via client objections.

## Available
- [[client-delivery-strawman]] — seeded.

## Ghost (not yet authored)
- Sales strawman — see ghost container.
- Marketing/ads strawman — see ghost container.
- Finance strawman — see ghost container.

These are authored on first need, per [[ghost-container-policy]].
